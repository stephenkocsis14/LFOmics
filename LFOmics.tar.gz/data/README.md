# Data Folder

This folder will contain all of the following data inputs and outputs:
* uploads
* processed
* results
